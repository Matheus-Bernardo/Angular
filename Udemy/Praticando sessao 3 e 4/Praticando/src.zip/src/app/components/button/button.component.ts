import { Component } from '@angular/core';

@Component({
  selector: 'app-button',
  standalone: true,
  imports: [],
  templateUrl: './componentes/button/button.component.html',
  styleUrl: './componentes/button/button.component.scss'
})
export class ButtonComponent {

}
